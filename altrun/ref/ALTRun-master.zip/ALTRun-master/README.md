ALTRun
======

ALTRun is an alternative Run. 

When you want to launch a program quickly with limited keystoke.  

It is written in Delphi 2007.

It runs under Windows system.

[Compile]
----------
Please add Dcu folder in root folder for compile.
