This zip-file contains the HotKeyManager Delphi component.

Refer to HotKeyManager.html and install.txt for documentation.

***** If you redistribute this package, please include all original files. *****

